<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'PureGlow' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '!gp6F_-,H[gRetc49Q/#KLT<@`HI>0Ys~vEM6GX#d2FojM0>V-f[2e{BX>=XO16.' );
define( 'SECURE_AUTH_KEY',  'TQ<}YWoU]K+euFNK|bchKhR1a~*2B+-7f[!ZU&:bp^^TR!Rpzk#z0f4^V sXjS;)' );
define( 'LOGGED_IN_KEY',    '%.V%Ei0d:{sVlFuM&}zcWpr>5Z(q6NsQ:a4A!lCNqsXY,&l:*B24y%yTF#WrzAqn' );
define( 'NONCE_KEY',        'jzna&=Hz*s2+ak{-c=MF.]~}e}dGkgdu#wo{5(]93YPZHstZ2 LWGTWoxh*Y+o$e' );
define( 'AUTH_SALT',        '^i8/]Wlbn/kwn.0f6Y@F@3$MoyO}bR%y-MC6INh{(4sO%Rz|tTQ;^YM:Ge_[l+T-' );
define( 'SECURE_AUTH_SALT', '9S1..%di}[#Mjk]J&Qj|/i9u?[Kc5mKSK05{1l*eS/hv;tLk>4L$;/;mS`RJ#D!;' );
define( 'LOGGED_IN_SALT',   'bSUQwoGRD_v}N8F:c>W;Q2pO?Ra4)0tekH+lT:f?r}<U@/^X,!EMe&R%>5:g.xH=' );
define( 'NONCE_SALT',       '4bSN[CxO W;&@gIXzg%A`4,B;geX81{tuB6CAS|]kp6A`Q}}%~H07~M_4QMAKMh-' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
